# Create your tests here.
import unittest
import views


class TestWeb(unittest.TestCase):

    def test_Sum(self):
        x=2
        y=3

        result=views.sums(x,y)
        self.assertEqual(result,5)


if __name__ == '__main__':
    unittest.main(argv=['first-arg-is-ignored'], exit=False)
