from . import views
from django.urls import path


app_name = 'webdatalabelling'

urlpatterns = [
	#/webdatalabeling/
	path('', views.IndexView.as_view(), name ='index'),

	path('register/',views.register, name = 'register'),

	#/webdatalabeling/p_id/
	path('<int:pk>/', views.DetailView.as_view(), name ='detail'),

	#/webdatalabelling/project/add/
	path('project/add/', views.ProjectCreate.as_view(), name= 'project_add'),


	#/webdatalabelling/project/add/
	path('project/<int:pk>/', views.ProjectUpdate.as_view(), name= 'project_update'),


	#/webdatalabelling/project/add/delete/
	path('project/<int:pk>/delete', views.ProjectDelete.as_view(), name= 'project_delete')
]
