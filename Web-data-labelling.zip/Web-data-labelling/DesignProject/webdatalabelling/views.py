from django.views import generic, View
from django.shortcuts import render, redirect
from django.views.generic import CreateView, UpdateView, DeleteView
from webdatalabelling import models
from django.urls import reverse_lazy
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import UserCreationForm


class IndexView(generic.ListView):
    template_name = 'webdatalabelling/index.html'
    context_object_name = "projects"

    def get_queryset(self):
        return models.Project.objects.all()


class DetailView(generic.DetailView):
    model = models.Project
    template_name = 'webdatalabelling/detail.html'


class ProjectCreate(CreateView):
    model = models.Project
    fields = ['p_owner', 'p_name', 'p_research', 'p_logo']


class ProjectUpdate(UpdateView):
    model = models.Project
    fields = ['p_owner', 'p_name', 'p_research', 'p_logo']


class ProjectDelete(DeleteView):
    model = models.Project
    success_url = reverse_lazy('webdatalabelling:index')


def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data['username']
            password = form.cleaned_data['password1']
            user = authenticate(username=username, password=password)
            login(request, user)
            return redirect('login')
    else:
        form = UserCreationForm()

    context = {'form': form}
    return render(request, 'registration/register.html', {'form': form})


def sums(x, y):
    return x + y
