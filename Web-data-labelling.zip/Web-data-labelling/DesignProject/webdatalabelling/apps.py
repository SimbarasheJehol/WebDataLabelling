from django.apps import AppConfig


class WebdatalabellingConfig(AppConfig):
    name = 'webdatalabelling'
