from django.db import models
from django.urls import reverse


# Create your models here.
class Project(models.Model):
    p_owner = models.CharField(max_length=250)
    p_name = models.CharField(max_length=250)
    p_research = models.CharField(max_length=250)
    p_logo = models.FileField()

    def get_absolute_url(self):
        return reverse('webdatalabelling:detail', kwargs={'pk': self.pk})

    def __str__(self):
        return self.p_owner + ' - ' + self.p_name


class Image(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE)
    file_type = models.CharField(max_length=10)
    image_title = models.CharField(max_length=250)
    is_labelled = models.BooleanField(default=False)

    def __str__(self):
        return self.image_title
