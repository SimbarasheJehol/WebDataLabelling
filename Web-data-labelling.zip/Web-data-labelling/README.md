# Web-data-labelling
Web Data Labelling is a system used as a tool to label media files (images and videos). It has users known as researchers and labellers. Researchers create projects and upload media files to those projects, then labellers identify objects in those media files that they know by name and add labels (names) to them.


[![Build Status](https://travis-ci.org/MKLThabo/Web-data-labelling.svg?branch=master)](https://travis-ci.org/MKLThabo/Web-data-labelling)
